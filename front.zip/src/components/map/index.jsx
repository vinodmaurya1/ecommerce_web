import React, { useState } from "react";
import PropTypes from "prop-types";
import MapBox, { Marker, Popup, NavigationControl } from "react-map-gl";
import "mapbox-gl/dist/mapbox-gl.css";
import { Link } from "react-router-dom";
import "./style.scss";

MapSection.propTypes = {};

function MapSection({ markers, className }) {
  const [popupOpen, setPopupOpen] = useState({});

  const [viewPort, setViewPort] = useState({
    longitude: 28.64583,
    latitude: 77.706243,
    zoom: 15,
  });

  return (
    <section className={`wd-feature-map ${className ? className : ""}`}>
      <div className="tf-slider slider-map style-1">
        <MapBox
          mapLib={import("mapbox-gl")}
          initialViewState={{
            ...viewPort,
          }}
          mapboxAccessToken="pk.eyJ1IjoidGhlbWVzZmxhdCIsImEiOiJjbGt3NGxtYncwa2F2M21saHM3M21uM3h2In0.9NbzjykXil1nELxQ1V8rkA"
          style={{ width: "100%", height: 600 }}
          mapStyle="mapbox://styles/mapbox/streets-v9"
          scrollZoom={false}
        >
          {markers.slice(0, 6).map((item) => {
            return (
              <div key={item.id}>
                <Marker
                  longitude={item.longitude}
                  latitude={item.latitude}
                  anchor="center"
                  closeOnClick={false}
                  onClick={(e) => {
                    setPopupOpen((prevItem) => ({
                      ...prevItem,
                      [item.id]: !prevItem[item.id],
                    }));
                  }}
                >
                  <div className="marker marker-logo-cty">
                    <img
                      src={item.img}
                      alt="img"
                      style={{ width: "28px", height: "28px" }}
                    />
                  </div>
                </Marker>
                {popupOpen[item.id] && (
                  <Popup
                    key={item.id}
                    longitude={item.longitude}
                    latitude={item.latitude}
                    anchor="center"
                    onClose={() => setPopupOpen(false)}
                    closeOnClick={false}
                    closeButton={true}
                    offsetLeft={10}
                  >
                    <div className="marker-popup">
                      <img src={item.img} alt="img" />
                      <div className="content">
                        <h4>{item.title}</h4>
                        <h3>
                          <Link to="/Jobsingle_v1">
                            {item.name}&nbsp;<span className="icon-bolt"></span>
                          </Link>
                        </h3>
                        <p>
                          <i className="icon-map-pin"></i>&nbsp;
                          {item.address}
                        </p>
                      </div>
                    </div>
                  </Popup>
                )}
              </div>
            );
          })}

          <NavigationControl position="top-left" />
        </MapBox>
      </div>
    </section>
  );
}

export default MapSection;
