import img1 from '../images/logo-company/cty8.png'
import img2 from '../images/logo-company/cty11.png'
import img3 from '../images/logo-company/cty4.png'
import img4 from '../images/logo-company/cty7.png'
import img5 from '../images/logo-company/cty2.png'
import img6 from '../images/logo-company/cty9.png'


const dataJobscontent = [
    {
        id: 1,
        img: img1,
        stt: 'active',
    },
    {
        id: 2,
        img: img2,
        stt: '',
    },
    {
        id: 3,
        img: img3,
        stt: '',
    },
    {
        id: 4,
        img: img4,
        stt: '',
    },
    {
        id: 5,
        img: img5,
        stt: '',
    },
    {
        id: 6,
        img: img6,
        stt: '',
    },

]

export default dataJobscontent;