const dataCate = [
    {
        id: 1,
        title: 'Human Resource',
        unit: '120 Jobs available',
    },
    {
        id: 2,
        title: 'Project Manager',
        unit: '120 Jobs available',
        active: 'active'
    },

    {
        id: 3,
        title: 'Delivery Driver',
        unit: '120 Jobs available',
    },
    {
        id: 4,
        title: 'Accounting',
        unit: '120 Jobs available',
    },
    {
        id: 5,
        title: 'Customer Service',
        unit: '120 Jobs available',
    },
    {
        id: 6,
        title: 'Data Science',
        unit: '120 Jobs available',
    },
    {
        id: 7,
        title: 'Engineering',
        unit: '120 Jobs available',
    },
    {
        id: 8,
        title: 'IT & Networking',
        unit: '120 Jobs available',
    },
    {
        id: 9,
        title: 'Sales & Marketing',
        unit: '120 Jobs available',
    },
    {
        id: 10,
        title: 'Writing',
        unit: '120 Jobs available',
    },
]

export default dataCate;