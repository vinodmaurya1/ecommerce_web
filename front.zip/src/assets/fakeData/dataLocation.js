import img1 from '../images/review/lo1.jpg'
import img2 from '../images/review/lo2.jpg'
import img3 from '../images/review/lo3.jpg'
import img4 from '../images/review/lo4.jpg'
import img5 from '../images/review/lo5.jpg'
import img6 from '../images/review/lo6.jpg'


const dataLocation = [
    {
        id: 1,
        img: img1,
        title: 'Germany',
        unit: 'Open Jobs (3)'
    },
    {
        id: 2,
        img: img2,
        title: 'United States',
        unit: 'Open Jobs (3)'
    },
    {
        id: 3,
        img: img3,
        title: 'United Kingdom',
        unit: 'Open Jobs (3)'
    },
    {
        id: 4,
        img: img4,
        title: 'Canada',
        unit: 'Open Jobs (3)'
    },
    {
        id: 5,
        img: img5,
        title: 'India',
        unit: 'Open Jobs (3)'
    },
    {
        id: 6,
        img: img6,
        title: 'France',
        unit: 'Open Jobs (3)'
    },

]

export default dataLocation;