import img1 from '../images/partners/Group-32.svg'
import img2 from '../images/partners/Group-33.svg'
import img3 from '../images/partners/Group-34.svg'
import img4 from '../images/partners/Group-35.svg'
import img5 from '../images/partners/Group-36.svg'
import img6 from '../images/partners/Group-37.svg'



const dataPartner = [
    {
        id: 1,
        img: img1
    },
    {
        id: 2,
        img: img2
    },
    {
        id: 3,
        img: img3
    },
    {
        id: 4,
        img: img4
    },
    {
        id: 5,
        img: img5
    },
    {
        id: 6,
        img: img6
    },
    {
        id: 7,
        img: img1
    },
    {
        id: 8,
        img: img2
    },
    {
        id: 9,
        img: img3
    },
    {
        id: 10,
        img: img4
    },
]

export default dataPartner;