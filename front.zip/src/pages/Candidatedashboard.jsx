import React from 'react';
import PropTypes from 'prop-types';

Candidatedashboard.propTypes = {
    
};

function Candidatedashboard(props) {
    return (
        <div>
            
        </div>
    );
}

export default Candidatedashboard;