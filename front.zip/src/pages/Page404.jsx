import React from 'react';
import PropTypes from 'prop-types';

Page404.propTypes = {
    
};

function Page404(props) {
    return (
        <div>
            
        </div>
    );
}

export default Page404;